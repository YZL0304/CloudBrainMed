package com.cloudbrainmed.auth.mapper;

//import org.apache.ibatis.annotations.Mapper;
//
//@Mapper
public interface UserMapper {
}